#!/bin/bash

youtube-dl --proxy socks5://192.168.1.38:7070/ -U

val1=$(cat u.txt|wc -l)

for ((i=1; i<=$val1; i++))
do
	sed -n "$i"p u.txt | xargs youtube-dl --proxy socks5://192.168.1.38:7070/
	mv /root/*.mp4 /mnt/mator/Mounted_NAS_18.223_DownLoad/PH/
done

